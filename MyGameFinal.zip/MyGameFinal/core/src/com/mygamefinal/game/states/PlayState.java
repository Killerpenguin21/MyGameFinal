package com.mygamefinal.game.states;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;
import com.mygamefinal.game.MyGameFinal;
import com.mygamefinal.game.inputs.MyInputProcessor;
import com.mygamefinal.game.sprites.Primary_Obstacle;
import com.mygamefinal.game.sprites.Protagonist;
import com.mygamefinal.game.sprites.goodShape;

import java.util.Random;

public class PlayState extends State  {
     Random random = new Random();
    int low = 100;
    int high = 250;
    private int tubeSpacing = random.nextInt(high - low) + low;


    MyInputProcessor inputProcessor = new MyInputProcessor();









    private int tubeCount = 4;


    private Protagonist bird;
    private goodShape goodshape;
    private Texture bg;




    private Array<Primary_Obstacle> tubes;
    private Primary_Obstacle ob;



    public PlayState(GameStateManager gsm) {
        super(gsm);
        Gdx.input.setInputProcessor(inputProcessor);






        bird = new Protagonist(50, MyGameFinal.HEIGHT/6);  //MySGame.WIDTH/2 - 50/2/* width of bird(to pos in middle) */ ,MySGame.HEIGHT/2);
        cam.setToOrtho(false, MyGameFinal.WIDTH / 2, MyGameFinal.HEIGHT / 2);
        bg = new Texture("testBackground.png");
        //ob = new Primary_Obstacle(MySGame.WIDTH/2);

        tubes = new Array<Primary_Obstacle>();

        for (int i = 1; i <= tubeCount; i++) {

            tubes.add(new Primary_Obstacle(i * (tubeSpacing + Primary_Obstacle.TUBE_WIDTH)));
        }
        System.out.println(tubeSpacing);


    }

    @Override
    protected void handleInput() {

//        if(inputProcessor.touchDown(Gdx.input.getX(),Gdx.input.getY(),0,0)){
//
//
//        }

        if(Gdx.input.justTouched()){

            bird.changeSpeed();





        }




    }



    @Override
    public void update(float dt) {

        handleInput();


        bird.update(dt);




        cam.position.x = bird.getPosition().x + 80;

        for (Primary_Obstacle tube : tubes) {

            if (cam.position.x - (cam.viewportWidth / 2) > tube.getPosTopTube().x + tube.getFire().getWidth()) {

                tube.reposition(tube.getPosTopTube().x + ((tube.TUBE_WIDTH + tubeSpacing) * tubeCount));
            }
        }


        cam.update();







    }


    @Override
    public void render(SpriteBatch sb) {

        sb.setProjectionMatrix(cam.combined); // to initiate cam
        sb.begin();
        sb.draw(bg, cam.position.x - (cam.viewportWidth / 2), 0);
        sb.draw(bird.getTexture(), bird.getPosition().x, bird.getPosition().y);



        for (Primary_Obstacle tube : tubes) {
            sb.draw(tube.getFire(), tube.getPosTopTube().x, tube.getPosTopTube().y);
            //sb.draw(tube.getBottomTube(), tube.getPosBotTube().x, tube.getPosBotTube().y);
        }
        //sb.draw(ob.getBadshapes(), ob.getPosition().x,ob.getPosition().y);

        sb.end();

    }

    @Override
    public void dispose() {

    }



}
