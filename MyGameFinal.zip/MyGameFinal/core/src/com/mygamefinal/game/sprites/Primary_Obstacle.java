package com.mygamefinal.game.sprites;


import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

import java.util.Random;

public class Primary_Obstacle {
    public static final int TUBE_WIDTH = 52;
    private static int  FLUCTUATION = 50;//260 if cam = MySGame.Width;// 130 if cam = MySGame.Width/2 // so it can move up and down randomly from 0 - 120
    private static int  tubeGap = 100; //400 if cam = MySGame.Width;  //100 if cam = MySGame.Width/2
    private static int ObstacleYPos = 75; //0 if cam = MySGame.Width ;// 120 if cam = MySGame.Width/2
    private Texture fire;
    private Vector2 postopTube,posbotTube;
    private Random random;

    public Primary_Obstacle(float x){
        fire = new Texture("fire.png");
        //bottomTube = new Texture("bottomtube.png");
        random = new Random();
        postopTube = new Vector2(x,random.nextInt(FLUCTUATION) +tubeGap + ObstacleYPos);
        posbotTube = new Vector2(x, postopTube.y - tubeGap);// - bottomTube.getHeight());



    }


    public Texture getFire() {
        return fire;
    }

    /*public Texture getBottomTube() {
        return bottomTube;
    }*/

    public Vector2 getPosTopTube() {
        return postopTube;
    }

    public Vector2 getPosBotTube() {
        return posbotTube;
    }

    public void reposition (float x ){

        postopTube.set(x,random.nextInt(FLUCTUATION) +tubeGap + ObstacleYPos);
        posbotTube.set(x, postopTube.y - tubeGap);// - bottomTube.getHeight());



    }

}

