package com.mygamefinal.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.mygamefinal.game.MyGameFinal;

public class DesktopLauncher {
	public static void main (String[] arg) {
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		config.width = MyGameFinal.WIDTH;
		config.height = MyGameFinal.HEIGHT;
		new LwjglApplication(new MyGameFinal(), config);
	}
}
