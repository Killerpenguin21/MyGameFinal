package com.mygamefinal.game.sprites;


import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;

public class Protagonist {
    private Vector3 position;
    private Vector3 velocity;
    private int GRAVITY = 0;
    private int Default = 150;
    private int Movement = Default;
    private Rectangle ProtagonistBounds;

    private int Fast = 250;
//    private int Slow = 50;


    private Texture bird;
    private Texture birdFinal;

    public Protagonist(int x, int y){

        position = new Vector3(x, y, 0);
        velocity = new Vector3(0, 0, 0);
        birdFinal = new Texture("main.png");
        bird = birdFinal;
        ProtagonistBounds = new Rectangle(x,y,bird.getWidth(),bird.getHeight());
    }



    public void update(float dt){
        if(position.y > 0)

            velocity.add(0, GRAVITY, 0);
        velocity.scl(dt);
        position.add(Movement * dt, velocity.y, 0);

        velocity.scl(1/dt);
        if(position.y<0){
            position.y = 0;}

        ProtagonistBounds.setPosition(position.x,position.y);







    }

    public Vector3 getPosition() {
        return position;
    }

    public Texture getTexture() {
        return bird;
    }

    public Rectangle getProtagonistBounds(){

        return ProtagonistBounds;

    }





    public void jump(){
        velocity.y = 250;

    }

    public void changeSpeed(){

        if(Movement == Default){
            Movement = Fast;

        }  else if (Movement == Fast){
            Movement = Default;}
//
//    } else if(Movement == Slow){
//
//        Movement = Default;
//    }

    }



//    public void changeshape(){
//
//        if(bird == Triangle) {
//            bird = Circle;
//
//
//        } else if(bird==Circle){
//
//            bird = Square;
//
//        }
//        else if(bird == Square){
//
//            bird = Triangle;
//
//        }
//
//    }
//
//    public void csf(){
//        if(bird == Circle){
//
//            GRAVITY = 1;
//        }else if(bird == Square){
//            GRAVITY = -1;
//        } else if (bird == Triangle){
//
//            GRAVITY = 0;
//        }
//    }









}
